package com.example.invetorylock

import com.example.invetorylock.retrofit.Container

interface ContainersInteraction {
    fun onContainerChosen(container: Container)
}