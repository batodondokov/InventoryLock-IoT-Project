package com.example.invetorylock.retrofit

data class AuthenticationResponse(val token: String)
