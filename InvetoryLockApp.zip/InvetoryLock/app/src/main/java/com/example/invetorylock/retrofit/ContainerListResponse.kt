package com.example.invetorylock.retrofit

data class ContainerListResponse(val containers: ArrayList<Container>)
