package com.example.invetorylock.retrofit

data class Container (val id: Int, val color: String, val status: Int)