package com.example.invetorylock.retrofit

data class AuthenticationRequest(
    val user_password: String,
    val user_email: String
    )
